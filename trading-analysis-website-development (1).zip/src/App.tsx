import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import WhyUs from './components/WhyUs';
import Coverage from './components/Coverage';
import QuoteForm from './components/QuoteForm';
import Testimonials from './components/Testimonials';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FloatingButtons from './components/FloatingButtons';

export default function App() {
  return (
    <div className="min-h-screen bg-white text-slate-800">
      <Header />
      <main>
        <Hero />

        {/* Trust strip */}
        <section className="bg-slate-900 text-white py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              {[
                { num: '15+', label: 'Years of Experience' },
                { num: '15,000+', label: 'Happy Customers' },
                { num: '50+', label: 'Cities Covered' },
                { num: '4.9★', label: 'Average Rating' },
              ].map((s) => (
                <div key={s.label}>
                  <div className="text-2xl sm:text-3xl font-black text-orange-400">{s.num}</div>
                  <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mt-1">
                    {s.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <Services />
        <WhyUs />
        <Coverage />
        <QuoteForm />
        <Testimonials />
        <FAQ />
        <Contact />
      </main>
      <Footer />
      <FloatingButtons />
    </div>
  );
}
