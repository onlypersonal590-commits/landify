import { useState } from 'react';

const FAQS = [
  {
    q: 'How much do packers and movers charge in Yeshwanthpur?',
    a: 'Local shifting within Bangalore typically starts at ₹4,000 for a 1BHK and goes up to ₹15,000+ for a 3BHK depending on distance and items. Interstate moves are calculated based on distance, volume and services. We provide a free, transparent quote after a home survey.',
  },
  {
    q: 'Are my belongings insured during the move?',
    a: 'Yes! Every move with Sainik Packers & Movers includes comprehensive transit insurance at no extra cost. In the rare case of damage, you are fully compensated as per the declared value of your goods.',
  },
  {
    q: 'How far in advance should I book?',
    a: 'For local moves in Bangalore, booking 2-3 days in advance is ideal. For interstate moves, we recommend 7-10 days. However, we also handle last-minute and same-day moves based on availability — just call us!',
  },
  {
    q: 'What packing materials do you use?',
    a: 'We use premium 3-layer packing: inner layer of bubble wrap for fragile items, middle layer of corrugated paper sheets, and outer layer of sturdy 5-ply cartons. Furniture is wrapped in stretch film and moved with blankets.',
  },
  {
    q: 'Do you provide unpacking and reassembly services?',
    a: 'Absolutely. Our full-service pack includes unpacking at your new home, reassembly of beds, tables, and other furniture, and disposal of packing materials. We leave your new place move-in ready.',
  },
  {
    q: 'Can you transport my car or bike separately?',
    a: 'Yes. We offer dedicated car and bike carrier services using enclosed carriers for maximum protection. We serve all major cities with full transit insurance for your vehicle.',
  },
  {
    q: 'Are there any hidden charges?',
    a: 'Never. We provide a detailed written quotation before the move. The price we quote is the price you pay — no surprises, no hidden costs. Toll, GST and labor are all included in the final quote.',
  },
  {
    q: 'Do you offer warehouse storage in Yeshwanthpur?',
    a: 'Yes, we have a clean, pest-free, CCTV-monitored warehouse facility near Yeshwanthpur. We offer both short-term and long-term storage with flexible monthly terms. Ideal if your new home is not yet ready.',
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
            Frequently Asked Questions
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Got Questions? <span className="text-orange-600">We Have Answers.</span>
          </h2>
        </div>

        <div className="space-y-3">
          {FAQS.map((faq, i) => {
            const isOpen = open === i;
            return (
              <div
                key={i}
                className={`rounded-2xl border-2 transition ${
                  isOpen ? 'border-orange-500 bg-orange-50/50' : 'border-slate-200 bg-white'
                }`}
              >
                <button
                  onClick={() => setOpen(isOpen ? null : i)}
                  className="w-full flex items-center justify-between gap-4 p-5 text-left"
                >
                  <span className="font-bold text-slate-900">{faq.q}</span>
                  <span
                    className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center font-black transition ${
                      isOpen
                        ? 'bg-orange-500 text-white rotate-45'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    +
                  </span>
                </button>
                {isOpen && (
                  <div className="px-5 pb-5 -mt-1 text-slate-600 leading-relaxed">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        <div className="mt-10 text-center p-6 rounded-2xl bg-slate-900 text-white">
          <h3 className="font-black text-xl">Still have questions?</h3>
          <p className="text-slate-400 mt-1">
            Our team is ready to help you 7 days a week.
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-3">
            <a
              href="tel:+918746060708"
              className="px-5 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 font-bold transition"
            >
              📞 Call Now
            </a>
            <a
              href="https://wa.me/918746060708"
              target="_blank"
              rel="noopener"
              className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 font-bold transition"
            >
              💬 WhatsApp
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
