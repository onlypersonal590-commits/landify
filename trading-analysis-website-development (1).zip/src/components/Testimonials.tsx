const TESTIMONIALS = [
  {
    name: 'Priya Sharma',
    location: 'Yeshwanthpur → Whitefield',
    rating: 5,
    text: 'Absolutely fantastic service! The team from Sainik Packers arrived on time, packed everything so carefully and not a single item was damaged. Highly recommend them for anyone moving in Bangalore.',
    date: '2 weeks ago',
    move: '2 BHK Household',
  },
  {
    name: 'Ravi Kumar',
    location: 'Bangalore → Mumbai',
    rating: 5,
    text: 'Interstate move from Yeshwanthpur to Mumbai was seamless. Their GPS tracking gave us peace of mind. Everything reached in perfect condition. Worth every rupee!',
    date: '1 month ago',
    move: '3 BHK Interstate',
  },
  {
    name: 'Anita Reddy',
    location: 'Rajajinagar → HSR Layout',
    rating: 5,
    text: 'Very professional team. Uniformed staff, polite behavior, and they handled our glass showpieces and antique furniture with such care. Transparent pricing, no hidden charges.',
    date: '3 weeks ago',
    move: '2 BHK Local',
  },
  {
    name: 'Mohammed Irfan',
    location: 'Yeshwanthpur → Hebbal',
    rating: 5,
    text: 'Used Sainik for office relocation. They moved 30 workstations over a weekend without any disruption. Very organized and professional. Will use them again!',
    date: '1 month ago',
    move: 'Office Relocation',
  },
  {
    name: 'Suresh Gowda',
    location: 'Peenya → Electronic City',
    rating: 5,
    text: 'Great experience from start to finish. The quotation was honest, the team was hardworking and my car was transported safely. Thank you Sainik team!',
    date: '2 months ago',
    move: 'Vehicle Transport',
  },
  {
    name: 'Deepa Nair',
    location: 'Bangalore → Kerala',
    rating: 5,
    text: 'Moving back to Kerala was stressful but Sainik made it so easy. The warehouse storage they offered for 2 weeks was clean and secure. Highly recommended!',
    date: '1 month ago',
    move: 'Interstate + Storage',
  },
];

export default function Testimonials() {
  return (
    <section id="reviews" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
            Customer Reviews
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            15,000+ Happy Customers <span className="text-orange-600">Trust Us</span>
          </h2>
          <div className="flex items-center justify-center gap-3 mt-4">
            <div className="flex text-amber-400 text-xl">★★★★★</div>
            <span className="font-black text-slate-900">4.9 / 5.0</span>
            <span className="text-slate-500">· Based on 2,847 reviews</span>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.name}
              className="bg-white rounded-2xl p-6 border border-slate-200 hover:shadow-xl transition"
            >
              <div className="flex text-amber-400 text-lg mb-3">
                {'★'.repeat(t.rating)}
              </div>
              <p className="text-slate-700 leading-relaxed">"{t.text}"</p>
              <div className="mt-5 pt-5 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <div className="font-black text-slate-900">{t.name}</div>
                  <div className="text-xs text-slate-500">{t.location}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] font-bold text-orange-600 uppercase tracking-wider">
                    {t.move}
                  </div>
                  <div className="text-xs text-slate-400 mt-0.5">{t.date}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <a
            href="https://google.com"
            target="_blank"
            rel="noopener"
            className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-white border-2 border-slate-200 hover:border-orange-500 font-bold text-slate-700 transition"
          >
            <span>📍</span> Read all reviews on Google
          </a>
        </div>
      </div>
    </section>
  );
}
