export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-14">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 flex items-center justify-center shadow-lg shadow-orange-500/30">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4 4 4-4m-4-5v9m-10-4a8 8 0 0116 0" />
                </svg>
              </div>
              <div className="leading-tight">
                <div className="font-black text-white text-lg">
                  SAINIK <span className="text-orange-400">PACKERS</span>
                </div>
                <div className="text-[10px] text-slate-500 font-semibold tracking-widest uppercase">
                  & Movers
                </div>
              </div>
            </div>
            <p className="text-sm leading-relaxed">
              Trusted packers and movers in Yeshwanthpur, Bangalore since 2008.
              Safe, insured and on-time relocation services across India.
            </p>
            <div className="mt-4 flex gap-2">
              {['FB', 'IG', 'YT', 'IN'].map((s) => (
                <a
                  key={s}
                  href="#"
                  className="w-9 h-9 rounded-lg bg-slate-800 hover:bg-orange-500 text-white text-xs font-bold flex items-center justify-center transition"
                >
                  {s}
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-black text-white mb-4 uppercase tracking-wider text-sm">
              Our Services
            </h4>
            <ul className="space-y-2 text-sm">
              {[
                'Household Shifting',
                'Office Relocation',
                'Car & Bike Transport',
                'Packing & Unpacking',
                'Loading & Unloading',
                'Warehouse Storage',
                'Local Shifting',
                'Interstate Movers',
              ].map((s) => (
                <li key={s}>
                  <a href="#services" className="hover:text-orange-400 transition">
                    {s}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-black text-white mb-4 uppercase tracking-wider text-sm">
              Quick Links
            </h4>
            <ul className="space-y-2 text-sm">
              {[
                { label: 'Home', href: '#home' },
                { label: 'About Us', href: '#why' },
                { label: 'Get Quote', href: '#quote' },
                { label: 'Coverage', href: '#coverage' },
                { label: 'Reviews', href: '#reviews' },
                { label: 'FAQ', href: '#faq' },
                { label: 'Contact', href: '#contact' },
              ].map((l) => (
                <li key={l.label}>
                  <a href={l.href} className="hover:text-orange-400 transition">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-black text-white mb-4 uppercase tracking-wider text-sm">
              Get In Touch
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="flex gap-3">
                <span className="text-orange-400">📍</span>
                <span>
                  #42, 1st Cross, Industrial Area,<br />
                  Yeshwanthpur, Bangalore 560022
                </span>
              </li>
              <li className="flex gap-3">
                <span className="text-orange-400">📞</span>
                <a href="tel:+918746060708" className="hover:text-orange-400">
                  +91 87460 60708
                </a>
              </li>
              <li className="flex gap-3">
                <span className="text-orange-400">💬</span>
                <a
                  href="https://wa.me/918746060708"
                  className="hover:text-orange-400"
                >
                  WhatsApp Us
                </a>
              </li>
              <li className="flex gap-3">
                <span className="text-orange-400">✉</span>
                <a
                  href="mailto:info@sainikpackers.in"
                  className="hover:text-orange-400"
                >
                  info@sainikpackers.in
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Licenses */}
        <div className="mt-10 pt-8 border-t border-slate-800 grid sm:grid-cols-3 gap-4 text-xs">
          <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
            <div className="text-orange-400 font-bold">GST NUMBER</div>
            <div className="text-white font-mono font-bold mt-1">29AABCS1234F1Z5</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
            <div className="text-orange-400 font-bold">LICENSE NO.</div>
            <div className="text-white font-mono font-bold mt-1">KA/BLR/2008/0542</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-800/50 border border-slate-700">
            <div className="text-orange-400 font-bold">INSURANCE</div>
            <div className="text-white font-mono font-bold mt-1">Full Transit Cover</div>
          </div>
        </div>

        {/* Copyright */}
        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-slate-500">
          <p>© 2026 Sainik Packers & Movers, Yeshwanthpur. All rights reserved.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-orange-400">Privacy Policy</a>
            <a href="#" className="hover:text-orange-400">Terms of Service</a>
            <a href="#" className="hover:text-orange-400">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
