export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
            Contact Us
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Visit Our Office in <span className="text-orange-600">Yeshwanthpur</span>
          </h2>
          <p className="mt-4 text-slate-600">
            We're just a call away. Come visit our office or reach out anytime.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-5">
          {/* Address card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
            <div className="w-12 h-12 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center text-2xl mb-4">
              📍
            </div>
            <h3 className="font-black text-slate-900 text-lg">Office Address</h3>
            <p className="mt-2 text-slate-600 leading-relaxed">
              Sainik Packers & Movers<br />
              #42, 1st Cross, Industrial Area,<br />
              Near Yeshwanthpur Metro Station,<br />
              Tumkur Road, Yeshwanthpur,<br />
              Bengaluru, Karnataka 560022
            </p>
            <a
              href="https://maps.google.com/?q=Yeshwanthpur+Bangalore"
              target="_blank"
              rel="noopener"
              className="inline-flex items-center gap-2 mt-4 text-sm font-bold text-orange-600 hover:text-orange-700"
            >
              Get Directions →
            </a>
          </div>

          {/* Contact info */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
            <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center text-2xl mb-4">
              📞
            </div>
            <h3 className="font-black text-slate-900 text-lg">Call / WhatsApp</h3>
            <div className="mt-3 space-y-2">
              <a
                href="tel:+918746060708"
                className="block p-3 rounded-xl bg-slate-50 hover:bg-orange-50 transition"
              >
                <div className="text-xs text-slate-500 font-semibold">Primary</div>
                <div className="font-black text-slate-900">+91 87460 60708</div>
              </a>
              <a
                href="tel:+918746060708"
                className="block p-3 rounded-xl bg-slate-50 hover:bg-orange-50 transition"
              >
                <div className="text-xs text-slate-500 font-semibold">Alternate</div>
                <div className="font-black text-slate-900">+91 87460 60708</div>
              </a>
              <a
                href="mailto:info@sainikpackers.in"
                className="block p-3 rounded-xl bg-slate-50 hover:bg-orange-50 transition"
              >
                <div className="text-xs text-slate-500 font-semibold">Email</div>
                <div className="font-black text-slate-900 text-sm">info@sainikpackers.in</div>
              </a>
            </div>
          </div>

          {/* Working hours */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
            <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center text-2xl mb-4">
              🕒
            </div>
            <h3 className="font-black text-slate-900 text-lg">Working Hours</h3>
            <div className="mt-3 space-y-2 text-sm">
              {[
                { day: 'Monday - Saturday', time: '8:00 AM - 9:00 PM' },
                { day: 'Sunday', time: '9:00 AM - 7:00 PM' },
                { day: 'Public Holidays', time: 'On call basis' },
              ].map((h) => (
                <div
                  key={h.day}
                  className="flex justify-between p-3 rounded-xl bg-slate-50"
                >
                  <span className="font-semibold text-slate-700">{h.day}</span>
                  <span className="font-bold text-slate-900">{h.time}</span>
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="text-xs font-bold text-emerald-700">
                  24/7 EMERGENCY SERVICE AVAILABLE
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Map */}
        <div className="mt-8 rounded-3xl overflow-hidden shadow-xl border border-slate-200 h-80 bg-slate-200 relative">
          <iframe
            title="Sainik Packers Yeshwanthpur Location"
            src="https://www.openstreetmap.org/export/embed.html?bbox=77.5400%2C13.0200%2C77.5800%2C13.0450&layer=mapnik&marker=13.0358%2C77.5613"
            className="w-full h-full border-0"
            loading="lazy"
          ></iframe>
          <div className="absolute top-4 left-4 bg-white rounded-xl shadow-xl p-3 border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="text-orange-500 text-xl">📍</span>
              <div>
                <div className="font-black text-slate-900 text-sm">Sainik Packers</div>
                <div className="text-xs text-slate-500">Yeshwanthpur, Bangalore</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
