const WHY_US = [
  {
    icon: '🛡',
    title: 'Full Transit Insurance',
    desc: 'Every move is covered. If anything gets damaged, you get compensated — no questions asked.',
  },
  {
    icon: '⏱',
    title: 'On-Time Guarantee',
    desc: 'We respect your time. Punctual pickup and delivery or you get a discount on your move.',
  },
  {
    icon: '💰',
    title: 'No Hidden Charges',
    desc: 'Transparent pricing with written quotation. The price we quote is the price you pay. Period.',
  },
  {
    icon: '👨‍🔧',
    title: 'Trained Professionals',
    desc: 'Uniformed, background-verified staff trained in safe packing and handling techniques.',
  },
  {
    icon: '📦',
    title: 'Premium Packing Material',
    desc: '3-layer packing with bubble wrap, corrugated sheets, foam and sturdy 5-ply cartons.',
  },
  {
    icon: '📍',
    title: 'GPS Tracked Trucks',
    desc: 'Track your shipment in real-time. Always know where your belongings are, 24/7.',
  },
];

const PROCESS = [
  {
    step: '01',
    title: 'Get a Free Quote',
    desc: 'Call us or fill the form. We provide an instant, transparent estimate.',
    icon: '📞',
  },
  {
    step: '02',
    title: 'Home Survey',
    desc: 'Our expert visits your home in Yeshwanthpur to assess items and plan the move.',
    icon: '🏠',
  },
  {
    step: '03',
    title: 'Safe Packing',
    desc: 'Our trained team carefully packs every item using premium materials.',
    icon: '📦',
  },
  {
    step: '04',
    title: 'Secure Transport',
    desc: 'GPS-tracked, covered carriers ensure your goods reach safely, on time.',
    icon: '🚛',
  },
  {
    step: '05',
    title: 'Unpack & Set Up',
    desc: 'We unpack, reassemble furniture, and set up your new home — hassle-free.',
    icon: '🎉',
  },
];

export default function WhyUs() {
  return (
    <>
      {/* Why Choose Us */}
      <section id="why" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
                Why Choose Sainik
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                Bangalore's Most{' '}
                <span className="text-orange-600">Trusted Packers & Movers</span>
              </h2>
              <p className="mt-4 text-slate-600 text-lg">
                Based in the heart of Yeshwanthpur, we've built our reputation on
                honest pricing, careful handling and keeping our promises — for over
                15 years.
              </p>

              <div className="mt-8 grid sm:grid-cols-2 gap-4">
                {WHY_US.map((item) => (
                  <div
                    key={item.title}
                    className="flex gap-4 p-4 rounded-xl hover:bg-orange-50 transition"
                  >
                    <div className="shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white text-2xl flex items-center justify-center shadow-lg shadow-orange-500/30">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="font-black text-slate-900">{item.title}</h4>
                      <p className="text-sm text-slate-600 mt-1">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <img
                src="/images/about-team.jpg"
                alt="Sainik Packers team"
                className="rounded-3xl shadow-2xl w-full object-cover aspect-[4/5]"
              />
              {/* Floating stats card */}
              <div className="absolute -bottom-6 -left-6 bg-white rounded-2xl shadow-2xl p-5 border-t-4 border-orange-500 max-w-xs">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-emerald-100 flex items-center justify-center text-3xl">
                    ⭐
                  </div>
                  <div>
                    <div className="flex items-baseline gap-2">
                      <span className="text-3xl font-black text-slate-900">4.9</span>
                      <span className="text-sm font-bold text-slate-500">/ 5.0</span>
                    </div>
                    <div className="text-xs text-slate-600 font-semibold">
                      Based on 2,847 reviews
                    </div>
                  </div>
                </div>
                <div className="mt-3 flex gap-0.5 text-amber-400 text-lg">
                  {'★★★★★'}
                </div>
              </div>
              {/* Top badge */}
              <div className="absolute -top-4 -right-4 bg-slate-900 text-white rounded-2xl px-4 py-3 shadow-2xl rotate-3">
                <div className="text-xs font-bold text-orange-400">GST VERIFIED</div>
                <div className="text-sm font-black">29AABCS1234F1Z5</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-slate-900 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-1/4 w-96 h-96 rounded-full bg-orange-500 blur-3xl"></div>
          <div className="absolute bottom-0 right-1/4 w-96 h-96 rounded-full bg-amber-500 blur-3xl"></div>
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <div className="inline-block px-3 py-1 rounded-full bg-orange-500/20 text-orange-400 text-xs font-bold uppercase tracking-wider mb-3">
              How We Work
            </div>
            <h2 className="text-3xl sm:text-4xl font-black text-white tracking-tight">
              A Simple <span className="text-orange-400">5-Step</span> Process
            </h2>
            <p className="mt-4 text-slate-400">
              Moving doesn't have to be stressful. Our proven process makes it smooth.
            </p>
          </div>

          <div className="grid md:grid-cols-5 gap-4">
            {PROCESS.map((p, i) => (
              <div key={p.step} className="relative">
                <div className="bg-slate-800/50 backdrop-blur border border-slate-700 rounded-2xl p-5 h-full hover:border-orange-500/50 transition group">
                  <div className="text-4xl mb-3">{p.icon}</div>
                  <div className="text-orange-400 text-xs font-black tracking-widest">
                    STEP {p.step}
                  </div>
                  <h4 className="text-white font-black text-lg mt-1 mb-2">{p.title}</h4>
                  <p className="text-sm text-slate-400 leading-relaxed">{p.desc}</p>
                </div>
                {i < PROCESS.length - 1 && (
                  <div className="hidden md:block absolute top-1/2 -right-2 w-4 h-0.5 bg-orange-500/40"></div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
