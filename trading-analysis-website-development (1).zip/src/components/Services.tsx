const SERVICES = [
  {
    icon: '🏠',
    title: 'Household Shifting',
    desc: 'Complete home relocation with safe packing of kitchen, bedroom, living room and all fragile items.',
    features: ['Full packing', 'Furniture拆装', 'Reassembly'],
  },
  {
    icon: '🏢',
    title: 'Office Relocation',
    desc: 'Zero-downtime office moves. We handle IT equipment, cabins, files and workstations carefully.',
    features: ['IT equipment', 'Weekend shifts', 'Minimal downtime'],
  },
  {
    icon: '🚗',
    title: 'Car & Bike Transport',
    desc: 'Door-to-door vehicle carrier service with full transit insurance across India.',
    features: ['Enclosed carriers', 'Insurance', 'Pan-India'],
  },
  {
    icon: '📦',
    title: 'Packing & Unpacking',
    desc: 'Multi-layer packing using bubble wrap, corrugated sheets and quality cartons by trained staff.',
    features: ['3-layer packing', 'Labelled boxes', 'Quality material'],
  },
  {
    icon: '💪',
    title: 'Loading & Unloading',
    desc: 'Trained manpower with modern equipment — hydraulic trolleys, ramps and lifting tools.',
    features: ['Trained team', 'Modern tools', 'Zero damage'],
  },
  {
    icon: '🏭',
    title: 'Warehouse & Storage',
    desc: 'Clean, CCTV-secured warehouse facilities in Yeshwanthpur for short & long-term storage.',
    features: ['24×7 CCTV', ' Pest-free', 'Flexible terms'],
  },
  {
    icon: '🛵',
    title: 'Local Shifting',
    desc: 'Same-day local moving within Bangalore. Affordable mini-truck and tempo services.',
    features: ['Same-day', '1BHK/2BHK/3BHK', 'Affordable'],
  },
  {
    icon: '🚛',
    title: 'Interstate Movers',
    desc: 'Relocate from Bangalore to any city in India. Dedicated trucks with GPS tracking.',
    features: ['GPS tracking', 'Dedicated truck', 'On-time'],
  },
];

export default function Services() {
  return (
    <section id="services" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
            Our Services
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            Complete Moving Solutions,{' '}
            <span className="text-orange-600">Under One Roof</span>
          </h2>
          <p className="mt-4 text-slate-600">
            From Yeshwanthpur to any corner of India — whatever you need to move,
            we've got you covered with professional, insured service.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {SERVICES.map((s) => (
            <div
              key={s.title}
              className="group relative bg-white rounded-2xl p-6 border border-slate-200 hover:border-orange-300 hover:shadow-2xl hover:shadow-orange-500/10 hover:-translate-y-1 transition-all duration-300"
            >
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-orange-100 to-amber-100 flex items-center justify-center text-3xl mb-4 group-hover:scale-110 transition">
                {s.icon}
              </div>
              <h3 className="font-black text-slate-900 text-lg mb-2">{s.title}</h3>
              <p className="text-sm text-slate-600 leading-relaxed mb-4">{s.desc}</p>
              <ul className="space-y-1.5">
                {s.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-xs text-slate-700 font-medium">
                    <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-[10px]">
                      ✓
                    </span>
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
