import { useState } from 'react';

export default function Hero() {
  const [quote, setQuote] = useState({
    from: 'Yeshwanthpur, Bangalore',
    to: '',
    type: 'household',
  });

  return (
    <section id="home" className="relative pt-28 pb-16 overflow-hidden">
      {/* Background image */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-movers.jpg"
          alt="Sainik Packers and Movers team"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900/95 via-slate-900/80 to-slate-900/40"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 grid lg:grid-cols-2 gap-10 items-center">
        {/* Left content */}
        <div className="text-white">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-500/20 border border-orange-400/40 backdrop-blur mb-5">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-bold tracking-wider text-orange-300">
              TRUSTED SINCE 2008 · 15+ YEARS
            </span>
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black leading-[1.05] tracking-tight">
            Safe & Stress-Free
            <span className="block mt-2 bg-gradient-to-r from-orange-400 to-amber-300 bg-clip-text text-transparent">
              Packers & Movers
            </span>
            <span className="block text-3xl sm:text-4xl lg:text-5xl mt-2 text-slate-200 font-bold">
              in Yeshwanthpur, Bangalore
            </span>
          </h1>

          <p className="mt-6 text-lg text-slate-300 max-w-xl leading-relaxed">
            From your home in Yeshwanthpur to anywhere in India — we handle every
            box, every piece of furniture with the care it deserves. Fully insured,
            on-time, guaranteed.
          </p>

          {/* Trust badges */}
          <div className="mt-8 flex flex-wrap gap-6">
            {[
              { icon: '✓', label: '100% Safe Transit' },
              { icon: '🛡', label: 'Full Insurance' },
              { icon: '⏱', label: 'On-Time Delivery' },
              { icon: '⭐', label: '4.9/5 Rating' },
            ].map((b) => (
              <div key={b.label} className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-sm">
                  {b.icon}
                </span>
                <span className="text-sm font-semibold text-white">{b.label}</span>
              </div>
            ))}
          </div>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#quote"
              className="px-6 py-3.5 font-bold text-slate-900 bg-gradient-to-r from-orange-400 to-amber-400 hover:from-orange-300 hover:to-amber-300 rounded-xl shadow-2xl shadow-orange-500/40 transition"
            >
              Get Instant Quote →
            </a>
            <a
              href="tel:+918746060708"
              className="px-6 py-3.5 font-bold text-white border-2 border-white/30 hover:bg-white/10 rounded-xl transition backdrop-blur"
            >
              📞 Call Now
            </a>
          </div>

          {/* Stats */}
          <div className="mt-10 grid grid-cols-3 gap-6 max-w-lg">
            {[
              { num: '15,000+', label: 'Happy Customers' },
              { num: '15+', label: 'Years Experience' },
              { num: '50+', label: 'Cities Covered' },
            ].map((s) => (
              <div key={s.label}>
                <div className="text-2xl sm:text-3xl font-black text-orange-400">{s.num}</div>
                <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider mt-1">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right quote card */}
        <div className="relative">
          <div className="bg-white rounded-3xl shadow-2xl p-6 sm:p-8 border-t-4 border-orange-500">
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-xl font-black text-slate-900">Get Free Quote</h3>
                <p className="text-xs text-slate-500 mt-0.5">Response within 15 minutes</p>
              </div>
              <div className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-600 text-xs font-bold">
                100% FREE
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Moving From
                </label>
                <div className="relative mt-1.5">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-500">📍</span>
                  <input
                    type="text"
                    value={quote.from}
                    onChange={(e) => setQuote({ ...quote, from: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium text-slate-800"
                    placeholder="Current location"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Moving To
                </label>
                <div className="relative mt-1.5">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-orange-500">🎯</span>
                  <input
                    type="text"
                    value={quote.to}
                    onChange={(e) => setQuote({ ...quote, to: e.target.value })}
                    className="w-full pl-10 pr-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium text-slate-800"
                    placeholder="Destination city / area"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Moving Type
                </label>
                <div className="grid grid-cols-3 gap-2 mt-1.5">
                  {[
                    { val: 'household', label: '🏠 Home' },
                    { val: 'office', label: '🏢 Office' },
                    { val: 'vehicle', label: '🚗 Vehicle' },
                  ].map((opt) => (
                    <button
                      key={opt.val}
                      onClick={() => setQuote({ ...quote, type: opt.val })}
                      className={`py-2.5 text-xs font-bold rounded-lg border-2 transition ${
                        quote.type === opt.val
                          ? 'border-orange-500 bg-orange-50 text-orange-700'
                          : 'border-slate-200 text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <a
                href="#quote"
                className="block w-full py-3.5 text-center font-black text-white bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 rounded-xl shadow-xl shadow-orange-500/30 transition"
              >
                GET MY FREE QUOTE →
              </a>

              <p className="text-[11px] text-slate-500 text-center">
                🔒 Your details are 100% safe. No spam, guaranteed.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
