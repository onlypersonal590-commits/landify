const LOCAL_AREAS = [
  'Yeshwanthpur', 'Rajajinagar', 'Malleshwaram', 'Basaveshwaranagar',
  'Vijayanagar', 'Mahalakshmi Layout', 'Peenya', 'Nagarathpet',
  'Chikkapete', 'Mahadevapura', 'Whitefield', 'Electronic City',
  'BTM Layout', 'Jayanagar', 'Bannerghatta', 'HSR Layout',
  'Koramangala', 'Indiranagar', 'Hebbal', 'RT Nagar',
];

const CITIES = [
  { city: 'Mumbai', time: '2-3 days' },
  { city: 'Delhi NCR', time: '3-4 days' },
  { city: 'Hyderabad', time: '1-2 days' },
  { city: 'Chennai', time: '1-2 days' },
  { city: 'Pune', time: '2-3 days' },
  { city: 'Kolkata', time: '4-5 days' },
  { city: 'Ahmedabad', time: '2-3 days' },
  { city: 'Goa', time: '1-2 days' },
  { city: 'Jaipur', time: '3-4 days' },
  { city: 'Chandigarh', time: '4-5 days' },
  { city: 'Lucknow', time: '3-4 days' },
  { city: 'Kerala', time: '2-3 days' },
];

export default function Coverage() {
  return (
    <section id="coverage" className="py-20 bg-gradient-to-br from-orange-50 via-amber-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
            Service Coverage
          </div>
          <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
            From Yeshwanthpur to{' '}
            <span className="text-orange-600">Anywhere in India</span>
          </h2>
          <p className="mt-4 text-slate-600">
            Local moves within Bangalore or interstate relocation — we cover it all
            with a strong network of 50+ cities.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Bangalore areas */}
          <div className="bg-white rounded-3xl p-8 shadow-xl border border-orange-100">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white flex items-center justify-center text-2xl">
                🏙
              </div>
              <div>
                <h3 className="font-black text-xl text-slate-900">Local Bangalore Areas</h3>
                <p className="text-xs text-slate-500">Same-day shifting available</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {LOCAL_AREAS.map((area) => (
                <span
                  key={area}
                  className="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 text-sm font-semibold hover:bg-orange-100 hover:text-orange-700 transition cursor-pointer"
                >
                  {area}
                </span>
              ))}
            </div>
            <p className="mt-5 text-xs text-slate-500 text-center">
              + 50 more areas across Bangalore ·{' '}
              <a href="#quote" className="text-orange-600 font-semibold hover:underline">
                Check your pincode →
              </a>
            </p>
          </div>

          {/* Interstate cities */}
          <div className="bg-slate-900 rounded-3xl p-8 shadow-xl text-white">
            <div className="flex items-center gap-3 mb-5">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-orange-500 to-amber-500 text-white flex items-center justify-center text-2xl">
                🚛
              </div>
              <div>
                <h3 className="font-black text-xl">Interstate Movers</h3>
                <p className="text-xs text-slate-400">Pan-India service · GPS tracked</p>
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-2">
              {CITIES.map((c) => (
                <div
                  key={c.city}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 border border-slate-700 transition"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-orange-400">📍</span>
                    <span className="font-bold">{c.city}</span>
                  </div>
                  <span className="text-xs text-slate-400 font-semibold">
                    {c.time}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
