import { useState } from 'react';

export default function QuoteForm() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    from: 'Yeshwanthpur, Bangalore',
    to: '',
    moveDate: '',
    size: '2BHK',
    type: 'household',
    notes: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setForm({ ...form, name: '', phone: '', email: '', to: '', moveDate: '', notes: '' });
    }, 4000);
  };

  const update = (field: string, value: string) => setForm({ ...form, [field]: value });

  return (
    <section id="quote" className="py-20 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="bg-gradient-to-br from-orange-500 to-amber-500 rounded-3xl p-1">
          <div className="bg-white rounded-[22px] p-6 sm:p-10">
            <div className="text-center mb-8">
              <div className="inline-block px-3 py-1 rounded-full bg-orange-100 text-orange-700 text-xs font-bold uppercase tracking-wider mb-3">
                Get Instant Quote
              </div>
              <h2 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
                Tell Us About Your Move
              </h2>
              <p className="mt-3 text-slate-600">
                Fill in the details — our team will call you back within 15 minutes
                with a transparent quote.
              </p>
            </div>

            {submitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 mx-auto rounded-full bg-emerald-100 flex items-center justify-center text-5xl mb-4">
                  ✅
                </div>
                <h3 className="text-2xl font-black text-slate-900">Quote Request Received!</h3>
                <p className="text-slate-600 mt-2">
                  Our team from Yeshwanthpur will call you within 15 minutes. Thank
                  you for choosing Sainik Packers & Movers.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Full Name *
                    </label>
                    <input
                      required
                      type="text"
                      value={form.name}
                      onChange={(e) => update('name', e.target.value)}
                      placeholder="Rajesh Kumar"
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Phone Number *
                    </label>
                    <input
                      required
                      type="tel"
                      pattern="[0-9]{10}"
                      value={form.phone}
                      onChange={(e) => update('phone', e.target.value)}
                      placeholder="8746060708"
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                    Email
                  </label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => update('email', e.target.value)}
                    placeholder="rajesh@example.com"
                    className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Moving From *
                    </label>
                    <input
                      required
                      type="text"
                      value={form.from}
                      onChange={(e) => update('from', e.target.value)}
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Moving To *
                    </label>
                    <input
                      required
                      type="text"
                      value={form.to}
                      onChange={(e) => update('to', e.target.value)}
                      placeholder="City or area"
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Move Date
                    </label>
                    <input
                      type="date"
                      value={form.moveDate}
                      onChange={(e) => update('moveDate', e.target.value)}
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Home Size
                    </label>
                    <select
                      value={form.size}
                      onChange={(e) => update('size', e.target.value)}
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium bg-white"
                    >
                      <option>1 RK</option>
                      <option>1 BHK</option>
                      <option>2 BHK</option>
                      <option>3 BHK</option>
                      <option>4 BHK</option>
                      <option>Villa</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                      Move Type
                    </label>
                    <select
                      value={form.type}
                      onChange={(e) => update('type', e.target.value)}
                      className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium bg-white"
                    >
                      <option value="household">Household</option>
                      <option value="office">Office</option>
                      <option value="vehicle">Vehicle</option>
                      <option value="industrial">Industrial</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                    Special Instructions
                  </label>
                  <textarea
                    rows={3}
                    value={form.notes}
                    onChange={(e) => update('notes', e.target.value)}
                    placeholder="Piano, aquarium, fragile items, narrow staircase, etc."
                    className="mt-1.5 w-full px-4 py-3 border-2 border-slate-200 rounded-xl focus:outline-none focus:border-orange-500 font-medium"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 font-black text-white bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 rounded-xl shadow-xl shadow-orange-500/30 transition text-lg"
                >
                  SUBMIT & GET FREE QUOTE →
                </button>

                <p className="text-xs text-slate-500 text-center">
                  🔒 We respect your privacy. Your details will never be shared.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
